﻿namespace Homies.Models
{
    public class TypesViewModel
    {
        public int Id { get; set; }
        public string Name { get; set; } = null!;
    }
}
