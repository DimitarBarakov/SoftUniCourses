﻿namespace Boardgames.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-TQ3OGMM\SQLEXPRESS;Database=Boardgames;Integrated Security=True;Encrypt=False";
    }
}
