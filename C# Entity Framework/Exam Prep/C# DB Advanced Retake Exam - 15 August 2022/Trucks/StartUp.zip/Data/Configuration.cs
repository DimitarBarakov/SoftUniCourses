﻿namespace Trucks.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-TQ3OGMM\SQLEXPRESS;Database=Trucks;Trusted_Connection=True";
    }
}