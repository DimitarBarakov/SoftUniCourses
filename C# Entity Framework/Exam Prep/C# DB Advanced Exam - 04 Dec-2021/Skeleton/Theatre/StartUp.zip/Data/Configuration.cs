﻿namespace Theatre.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-TQ3OGMM\SQLEXPRESS;Database=Theatre;Trusted_Connection=True";
    }
}
