﻿namespace TeisterMask.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-TQ3OGMM\SQLEXPRESS;Database=TeisterMask;Trusted_Connection=True";
    }
}
