﻿namespace Footballers.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-TQ3OGMM\SQLEXPRESS;Database=FootballersExam;Trusted_Connection=True";
    }
}
