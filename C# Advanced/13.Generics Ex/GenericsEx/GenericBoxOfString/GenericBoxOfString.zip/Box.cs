﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GenericBoxOfString
{
    public class Box<t>
    {
        private t value;

        public Box(t value)
        {
            this.value = value;
        }
        public string ToString()
        {
            return $"{typeof(t)}: {this.value}";
        }
    }
}
