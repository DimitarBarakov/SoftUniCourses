﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BorderControl
{
    public interface ICreature
    {
        public string Id { get; set; }
    }
}
