﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Telephony
{
    public interface IPhone
    {
        void Calling(string number);
    }
}
